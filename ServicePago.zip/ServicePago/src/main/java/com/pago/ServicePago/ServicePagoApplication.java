package com.pago.ServicePago;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicePagoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServicePagoApplication.class, args);
    }
}
